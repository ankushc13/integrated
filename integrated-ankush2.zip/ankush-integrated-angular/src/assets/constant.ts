const constants = {
    userExist: `User exists with same email Id`,
    invalid: `id or password is incorrect`,
    notepadImg: `../../assets/Images/Notepad_icon.svg.png`,
    noItem: `../../assets/Images/noitem.png`,
    passwordError: `password should contain at least an uppercase and a lowercase character, a number, and a special character`,
    nameError: `name is not valid`,
    ageError: `Age should be between 20 and 100 years`,
    mobileNumberError: `Mobile number should have 10 digits`,
    fieldRequired: 'This field is required',
    emailError : `Email Id should be valid`,
    specialityError: `Speciality should have atleast 10 characters`,
    accountCreated: `Account created successfully`,
    pinCodeError: `Pincode should have 6 digits`,
    cityError: `City should have 3 to 20 characters`,
    stateError: `State should have 3 to 20 characters`,
    countryError: `Country should have 3 to 20 characters`,
    appointmentDateError: `Date should be any upcoming 7 days`,
    appointmentScheduled: `Your appointment is scheduled successfully`,
    appointmentRescheduled: `Your appointment is rescheduled successfully`,
    appointmentCancelled: `Your appointment is cancelled successfully`,
    cancelConfirm: `Are you sure you need to cancel the appointment?`,
    noCoaches:`No coaches currently available`
};

export default constants;
