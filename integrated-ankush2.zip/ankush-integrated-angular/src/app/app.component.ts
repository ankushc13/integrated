import { Component, ViewChild , OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from './data.service';
import { HomeComponent } from './home/home.component';
import { ContentChild } from '@angular/core';
import { Cart } from './products/cart/Cart'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'App';
  logout = true;
  bProfile = false;
  sProfile = false;
  searchText = '';
  totalCart = 0;
  selectedProducts: any = [];
  userId: number|null=null;
  constructor(private router: Router,private dataService:DataService) {
    router.events.subscribe((val) => {
      this.logout = false;
      this.bProfile = false;
      this.sProfile = false;
      this.userId = parseInt(localStorage.getItem('userId')+'');
        if(!Number.isNaN(this.userId) && this.userId!==null && this.userId!==0){
          this.logout = true;
          this.bProfile = true;
          this.sProfile = false;
        }
      if (router.url === '/buyer' || router.url === '/buyer/profile') {
        this.logout = true;
        this.bProfile = true;
        this.sProfile = false;
        
      }
    });
    this.dataService.getCart().subscribe(data=>{
      this.totalCart = data;
      console.log(this.totalCart)
    })
  }
  ngOnInit(): void {
    this.userId = parseInt(localStorage.getItem('userId')+'');
    console.log("userId",this.userId);
    if(!Number.isNaN(this.userId) && this.userId!==null && this.userId!==0){
      localStorage.setItem('userId',this.userId+'');
      localStorage.removeItem('setupTime')
    }
    else{
      this.userId = 0;
      localStorage.setItem('userId',0+'');
    }
    this.selectedProducts = JSON.parse(localStorage.getItem('selectedProducts')+'');
    if(this.selectedProducts!=null){
      this.selectedProducts.forEach((cart: Cart) =>{
          this.totalCart+=cart.quantity
      })
      this.dataService.setCart(this.totalCart);
      }
    
        this.clearCart()
    
  }
  clearCart(){
    var hours = 168; //1 week
    var now = new Date().getTime();
    var setupTime = parseInt(localStorage.getItem('setupTime')+'');
    if (setupTime == null) {
        localStorage.setItem('setupTime', now+'')
    } else {
        if(now-setupTime > hours*60*60*1000) {
            localStorage.removeItem('selectedProducts')
            localStorage.setItem('setupTime', now+'');
            this.logoutFn();
        }
    }
  }
  searchProduct(value:any){
    this.dataService.setValue(value);

}
  logoutFn() {
    this.userId = 0;
    this.selectedProducts = JSON.parse(localStorage.getItem('selectedProducts')+'');
    console.log(this.selectedProducts)
    if(this.selectedProducts!==undefined && this.selectedProducts!==null){
      this.selectedProducts.forEach((cart: Cart) =>{
          this.dataService.addCart(cart).subscribe(res=>{
            console.log(res)
          });
      })
      }
    localStorage.clear();
    this.totalCart = 0;
    this.dataService.setCart(this.totalCart);
    this.logout = false;
    this.bProfile = false;
    this.sProfile = false;
    this.router.navigate(['/home'])
  }

}

