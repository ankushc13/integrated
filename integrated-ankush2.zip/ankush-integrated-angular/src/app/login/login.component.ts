import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { LoginService } from './login.service';
import constant from '../../assets/constant';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  readonly CONSTANT = constant;
  loginForm!: FormGroup;
  role!: string;
  fail!:boolean;
  id!:number;
  private routeSub!: Subscription;

  constructor(private router: Router,private route: ActivatedRoute,private formBuilder :FormBuilder,private loginService:LoginService) {}

  ngOnInit() {
    this.loginForm=this.formBuilder.group({
      userId :['',[Validators.required]],
      password : ['',[Validators.required]]
    })
    
  }
  userLogin(){
    this.fail=false;
    let url ="http://localhost:9000/users/login";
    this.loginService.login(this.loginForm.value,url).subscribe(res=>{this.id= this.loginForm.controls["userId"].value
    if(!this.fail){
      localStorage.setItem('userId', ''+this.id);
      localStorage.setItem('token',res.headers.get('token'))
      console.log(res.headers.get('token'));
      let role = '';
      this.loginService.getRole(res.headers.get('token')).subscribe(data=>{
        console.log(data.body);
        role=data.body
        this.router.navigate(['../../'+role]);
      });
    }
  },error=>{this.fail=true
    console.log(error);
  });
    
  }

}
