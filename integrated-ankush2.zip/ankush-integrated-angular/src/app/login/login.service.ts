import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from "rxjs/operators";
import { switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  
  constructor(private http:HttpClient) { }

  login(data:any,url:string):Observable<any>{
    console.log(data,url)
    const requestOptions: Object = {
    responseType: 'text',
    observe: 'response'
  }
    return this.http.post<any>(url,data,requestOptions).pipe(map(res=>{
      if(!res){
        throw new Error('Invalid');
      }
      else{
        console.log(res.headers.get('token'))
        return res;
      }
    }));
  }

  getRole(token:any):Observable<any>{
    const requestOptions: Object = {
      responseType: 'text',
      observe: 'response',
      headers: {
        'token': token,
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Origin': 'http://localhost:4200',
        'content-type': 'application/json',
      }
    }
    return this.http.get<any>("http://localhost:9000/users/authorize",requestOptions);
  }
}
