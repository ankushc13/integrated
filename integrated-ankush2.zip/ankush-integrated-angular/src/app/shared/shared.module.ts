import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterPipe } from './pipe/filter.pipe';
import { MinPipe } from './pipe/min.pipe'; 
import { FilterWishPipe } from './pipe/filter.wishlist.pipe';
import { MaxOfferPipe } from './pipe/max.offer.pipe';
import { SharedRoutingModule } from './shared-routing.module';
import { SharedComponent } from './components/shared/shared.component';


@NgModule({
  declarations: [
    SharedComponent ,
    MaxOfferPipe,
    FilterPipe,
    MinPipe,
    FilterWishPipe
  ],
  imports: [
    CommonModule,
    SharedRoutingModule
  ],
  exports: [
    MaxOfferPipe,
    FilterPipe,
    MinPipe,
    FilterWishPipe
  ]
})
export class SharedModule { }
