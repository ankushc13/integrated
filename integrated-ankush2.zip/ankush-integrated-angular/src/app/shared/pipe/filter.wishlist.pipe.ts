import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'wishFilter' })
export class FilterWishPipe implements PipeTransform {
  /**
   * Pipe filters the list of elements based on the search text provided
   *
   * @param items list of elements to search in
   * @param searchText search string
   * @returns list of elements filtered by search text or []
   */
  transform(product: any[],wish: any[]): any[] {
    let arr = []
    if (!wish) {
      return [];
    }
    if (!product) {
      return [];
    }
    return product.filter(it => {
      let fnd = false;
      wish.forEach((itm:any)=>{
        if(itm.productId===it.productId){
          fnd = true;
        }
      })
      return fnd;
    });
  }
}