import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'maxFilter' })
export class MaxOfferPipe implements PipeTransform {
  /**
   * Pipe filters the list of elements based on the search text provided
   *
   * @param items list of elements to search in
   * @param searchText search string
   * @returns list of elements filtered by search text or []
   */
  transform(items: any[]): any {
    if (Array.isArray(items) && !items.length) {
      return null;
  }
  if(!Array.isArray(items)){
    return null;
  }
    let max = -Number.POSITIVE_INFINITY;
    let obj:any = '';
    items.forEach(function (v) {
      if(v.discount>max){
        obj = v
        max = v.discount
      }
    }); 
    if(obj != undefined && obj != null){
      return obj.description
    }
    return null;
    }
  }