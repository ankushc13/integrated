import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'minFilter' })
export class MinPipe implements PipeTransform {
  /**
   * Pipe filters the list of elements based on the search text provided
   *
   * @param items list of elements to search in
   * @param searchText search string
   * @returns list of elements filtered by search text or []
   */
  transform(items: any[]): any {
    let min = Number.POSITIVE_INFINITY;
    items.forEach(function (v) {
        min = Math.min(v.price,min)
    }); 
    return min;
    }
  }