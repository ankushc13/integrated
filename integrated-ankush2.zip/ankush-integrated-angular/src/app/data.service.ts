import { Injectable } from '@angular/core';  
import { Subject } from 'rxjs';
import { BehaviorSubject, Observable } from '../../node_modules/rxjs';
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

@Injectable()  
export class DataService {  
  
  private valueObs: BehaviorSubject<string> = new BehaviorSubject<string>('');
  private cartValue: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  constructor(private http: HttpClient) {
    
}

  public getCarts(id:any):Observable<any[]>{
    return this.http.get<any[]>("http://localhost:9000/carts/".concat(''+id));
    }
    public addOrder(data:any):Observable<any>{
      const requestOptions: Object = {
        responseType: 'text',
        observe: 'response'
      }
      console.log(JSON.stringify(data));
      return this.http.post<any>("http://localhost:9000/orders/add",data,requestOptions).pipe();
    }
    public addWishList(data:any):Observable<any>{
      const requestOptions: Object = {
        responseType: 'text',
        observe: 'response'
      }
      console.log(JSON.stringify(data));
      return this.http.post<any>("http://localhost:9000/wish/add",data,requestOptions).pipe();
    }
    public removeCart(id:any):Observable<any[]>{
      const requestOptions: Object = {
        responseType: 'text',
        observe: 'response'
      }
      return this.http.delete<any[]>("http://localhost:9000/carts/".concat(''+id),requestOptions).pipe();
      }
    public addCart(data:any):Observable<any>{
      const requestOptions: Object = {
        responseType: 'text',
        observe: 'response'
      }
      console.log(JSON.stringify(data));
      return this.http.post<any>("http://localhost:9000/carts/add",data,requestOptions).pipe();
    }

 public setValue(value: string):void {
     this.valueObs.next(value);
     this.getValue();
 }

 public getValue():Observable<string> {
     return this.valueObs;

 }
 public setUserName(value: string):void {
  this.valueObs.next(value);
  this.getValue();
}

public getUserName():Observable<string> {
  return this.valueObs;

}
 public setCart(value: number):void {
  this.cartValue.next(value);
  this.getValue();
}

public getCart():Observable<number> {
  return this.cartValue;

}
getUser(id:any):Observable<any>{
  const requestOptions: Object = {
    headers: {
      'token': localStorage.getItem('token')
    }
  }
  return this.http.get<any>("http://localhost:9000/users/".concat(''+id),requestOptions);
}
} 