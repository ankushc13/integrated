import { Component, OnInit } from '@angular/core';
import { AbstractControlOptions, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { SignupService } from './signup.service';
import constant from '../../assets/constant';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  readonly CONSTANT = constant;
  userForm!: FormGroup;
  role!: string;
  success!:boolean;
  id!:any;
  existEmail!:boolean;

  public isChecked = false;

  private routeSub!: Subscription;
  constructor(private route: ActivatedRoute,private formBuilder :FormBuilder,private signupService:SignupService) {}
  ngOnInit() {
  
    this.userForm=this.formBuilder.group({
      name :['',[Validators.required,Validators.pattern('[a-zA-Z ]+')]],
      password : ['',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*\\W).*$')]],
      confirmPassword : ['',[Validators.required]],
      email:['',[Validators.required,Validators.pattern('^[\\w\\.-]+@([\\w-]+\\.)+[\\w-]{2,4}$')]],
      accountType: ['',[Validators.required]]
      },
      { validators: [this.ConfirmedValidator('password', 'confirmPassword')] })
  }
  userRegister(){
    let url ="http://localhost:9000/users";
    this.success=false;
    this.existEmail=false;
    this.signupService.register(this.userForm.value,url).subscribe(res=>{
        for (const [key, value] of Object.entries(res)) {
          if(key=='id'){
            this.id=value;
            this.success=true;
            console.log("value",this.id)
          }
        }
          },error=>{
            console.log(JSON.parse(error.error).messages[0])
            if((JSON.parse(error.error).messages[0])==="email already exist"){
              this.existEmail = true;
            }
          });

  }
  clearExistEmail(){
    this.existEmail = false;
  }
  ConfirmedValidator(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];
      if (
        matchingControl.errors &&
        !matchingControl.errors.confirmedValidator
      ) {
        return;
      }
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ confirmedValidator: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
}
}
