import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map } from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private http:HttpClient) { }

  register(data:any,url:string):Observable<any>{
    const requestOptions: Object = {
      responseType: 'text',
      observe: 'response'
    }
    console.log(JSON.stringify(data));
    return this.http.post<any>(url,data,requestOptions).pipe(catchError(this.erroHandler));
  }
  erroHandler(error: HttpErrorResponse) {
    return throwError(() => error);

  }
}
