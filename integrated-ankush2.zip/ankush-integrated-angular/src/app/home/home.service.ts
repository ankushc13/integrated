import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from "rxjs/operators";
import { switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  
  constructor(private http:HttpClient) { }


}
