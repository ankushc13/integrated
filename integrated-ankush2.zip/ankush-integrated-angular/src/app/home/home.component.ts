import { HomeService } from './home.service';
import { Component, OnInit, Input } from '@angular/core';
import { DataService } from '../data.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  filterText = '';


  constructor(private router: Router,private homeService:HomeService,private dataService:DataService) {
    this.dataService.getValue().subscribe(data=>{
      this.filterText = data;
    })
   }
  ngOnInit(){
    this.router.navigate(['/products']);
  }

}
