import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { DataService } from '../data.service';
import { Cart } from '../products/cart/Cart';

@Component({
  selector: 'app-buyer',
  templateUrl: './buyer.component.html',
  styleUrls: ['./buyer.component.css'],
})
export class BuyerComponent implements OnInit {
  selectedProducts: any = [];
  selectedProductsDB: any = [];
  userId: number = 0;
  totalCart: number = 0;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private dataService: DataService
  ) {
    this.userId = parseInt(localStorage.getItem('userId') + '');
    this.dataService.getCarts(this.userId).subscribe((data) => {
      this.selectedProducts = JSON.parse(localStorage.getItem('selectedProducts') + '');
      this.selectedProductsDB = data;
      this.setCart();
    });
    this.dataService.getUser(this.userId).subscribe(data=>{
      this.dataService.setUserName(data.name);
    });
    
  }

  ngOnInit(): void {
    this.router.navigate(['../products']);
  }
  setCart() {
    console.log('before', this.selectedProducts);
    console.log('db', this.selectedProductsDB);
    var union = [];
    if (this.selectedProducts !== null) {
      union = this.selectedProducts;
      if (this.selectedProductsDB !== null) {
        union = this.selectedProducts.concat(this.selectedProductsDB);
      }
      for (var i = 0; i < union.length; i++) {
        for (var j = i + 1; j < union.length; j++) {
          if (this.areEqual(union[i], union[j])) {
            if (union[i].orderId !== null) {
              union[i] = this.modifyCart(union[i], union[j]);
            } else {
              union[i] = this.modifyCart(union[j], union[i]);
            }
            union.splice(j, 1);
            j--;
          }
        }
        console.log("setCart",this.userId)
        union[i].userId = this.userId;
      }
    }
    else{
      this.selectedProducts = []
      if (this.selectedProductsDB !== null) {
        union = this.selectedProducts.concat(this.selectedProductsDB);
      }
    }
    union.forEach((res:any)=>{
        this.totalCart+=res.quantity
    })
    console.log('after', union);
    console.log('total', this.totalCart);
    this.dataService.setCart(this.totalCart);
    localStorage.setItem('selectedProducts',JSON.stringify(union))
  }
  areEqual(g1: Cart, g2: Cart) {
    return g1.productId === g2.productId && g1.sellerId === g2.sellerId;
  }
  modifyCart(db: Cart, cart: Cart): Cart {
    db.quantity = (db.quantity + cart.quantity) > 4 ? 4 : (db.quantity + cart.quantity);
    db.totalPrice = db.price * db.quantity;
    db.totalDeliveryCharge = db.deliveryCharge * db.quantity;
    return db;
  }
}
