import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BuyerRoutingModule } from './buyer-routing.module';
import { BuyerComponent } from './buyer.component';
import { BuyerProfileComponent } from './buyer-profile/buyer-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BuyerOrderComponent } from './buyer-order/buyer-order.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    BuyerComponent,
    BuyerProfileComponent,
    BuyerOrderComponent,
    WishlistComponent
  ],
  imports: [
    CommonModule,
    BuyerRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule
  ]
})
export class BuyerModule { }
