import { Component, OnInit } from '@angular/core';
import { WishlistService } from './wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  products: any[];
  wish!:any[]
  userId = 0;
  constructor(private wishListService:WishlistService) {
    this.products = JSON.parse(localStorage.getItem('totalProducts')+'');
    this.userId = parseInt(localStorage.getItem('userId')+'');
    this.wishListService.getWish(this.userId).subscribe(res=>this.wish=res)
   }

  ngOnInit(): void {
  }
  delete(id:number){
    this.wishListService.deleteWish(id).subscribe(res=>{
      console.log(res)
      this.wishListService.getWish(this.userId).subscribe(res=>this.wish=res)

    })
  }

}
