import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {

  constructor(private http: HttpClient) {
   
}

getWish(id:number):Observable<any[]>{
    return this.http.get<any[]>("http://localhost:9000/wish/".concat(''+id));
  }

  deleteWish(id:any):Observable<any[]>{
    const requestOptions: Object = {
      responseType: 'text',
      observe: 'response'
    }
    return this.http.delete<any[]>("http://localhost:9000/wish/".concat(''+id),requestOptions).pipe();
    }
}
