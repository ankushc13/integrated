export class Order {
    public orderId: number|null=null;
    public cartId: number|null=null;
    public productId: number|null=null;
    public userId: number|null=null;
    public sellerId: number|null=null;
    public productName: string='';
    public quantity: number=0;
    public dateOfPurchase: string='';
    public price: number=0;
    public totalPrice: number=0;
    public deliveryCharge: number=0;
    public totalDeliveryCharge: number=0;
    public sellerName: string='';
    public discount: number=0;
    public imageUrl: string='';
    public orderType: string='open';
}

