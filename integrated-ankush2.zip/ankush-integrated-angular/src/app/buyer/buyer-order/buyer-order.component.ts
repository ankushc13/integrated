import { Component, OnInit } from '@angular/core';
import { BuyerOrderService } from './buyer-order.service';
import { Order } from './Order';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-buyer-order',
  templateUrl: './buyer-order.component.html',
  styleUrls: ['./buyer-order.component.css']
})
export class BuyerOrderComponent implements OnInit {
  userId:number = 0;
  orders: any = [];
  addSellerReviewForm!: FormGroup;
  addProductReviewForm!: FormGroup;
  userName = '';
  constructor(private buyerOrderService :BuyerOrderService,private dataService :DataService,private formBuilder :FormBuilder) {
    this.userId = parseInt(localStorage.getItem('userId')+'');
     
   }

  ngOnInit(): void {
    this.addProductReviewForm=this.formBuilder.group({
      productId :[''],
      userName :[''],
      description : [''],
      rating : ['']
    })
    this.addSellerReviewForm=this.formBuilder.group({
      sellerId :[''],
      userName :[''],
      description : [''],
      rating : ['']
    })
    this.buyerOrderService.getOrder(this.userId).subscribe(res=>{
      this.orders=res;
    })
  }
  cancel(order:Order): void {
    this.buyerOrderService.addOrder(order).subscribe(res=>{
      console.log(order)
    })
    this.buyerOrderService.getOrder(this.userId).subscribe(res=>{
      this.orders=res;
    })
  }
  return(order:Order): void {
    this.buyerOrderService.addOrder(order).subscribe(res=>{
      console.log(order)
    })
    this.buyerOrderService.getOrder(this.userId).subscribe(res=>{
      this.orders=res;
    })
  }
  reviewProduct(id:number): void {
    this.dataService.getUserName().subscribe(res=>{
      this.addProductReviewForm.patchValue({
        userName: res, 
      });
      this.buyerOrderService.addReviewProduct(id,this.addProductReviewForm.value).subscribe(res=>{
        console.log(res)
      })
    })
    
  }
  reviewSeller(id:number): void {
    console.log("id",id)
    console.log(this.addSellerReviewForm.value);
  }

}
