import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BuyerOrderService {

  constructor(private http:HttpClient) { }

  getOrder(id:any):Observable<any[]>{
    return this.http.get<any[]>("http://localhost:9000/orders/".concat(''+id));
  }
  public addOrder(data:any):Observable<any>{
    const requestOptions: Object = {
      responseType: 'text',
      observe: 'response'
    }
    console.log(JSON.stringify(data));
    return this.http.post<any>("http://localhost:9000/orders/add",data,requestOptions).pipe();
  }
  public addReviewProduct(id:number,data:any):Observable<any>{
    const requestOptions: Object = {
      responseType: 'text',
      observe: 'response'
    }
    return this.http.post<any>("http://localhost:9000/products/review/".concat(''+id),data,requestOptions).pipe();
  }
  

}
