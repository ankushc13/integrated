import { TestBed } from '@angular/core/testing';

import { BuyerOrderService } from './buyer-order.service';

describe('BuyerOrderService', () => {
  let service: BuyerOrderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BuyerOrderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
