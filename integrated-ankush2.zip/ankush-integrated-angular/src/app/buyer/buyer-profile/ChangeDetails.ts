export class ChangeDetails {
    public userId: number|null=null;
    public password:string|null=null;
    public name:string|null=null;
}

