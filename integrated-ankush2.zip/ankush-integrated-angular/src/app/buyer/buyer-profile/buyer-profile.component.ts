import { Component, OnInit } from '@angular/core';
import { ChangeDetails } from './ChangeDetails';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import constant from '../../../assets/constant'
import { BuyerProfileService } from './buyer-profile.service';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-buyer-profile',
  templateUrl: './buyer-profile.component.html',
  styleUrls: ['./buyer-profile.component.css']
})
export class BuyerProfileComponent implements OnInit {
  editPasswordForm!: FormGroup;
  editNameForm!: FormGroup;
  readonly CONSTANT = constant;
  userId:number = 0;
  editPassword!:boolean;
  editName!:boolean;
  userDetail!:any;
  isChecked = false;
  isCheck = false;
  oldPassword = false;
  constructor(private dataService :DataService,private formBuilder :FormBuilder,private buyerProfileService:BuyerProfileService) {
    this.userId = parseInt(localStorage.getItem('userId')+'');
    this.editName = false;
    this.editPassword = false;
  }
  ngOnInit(): void {
    this.editPasswordForm=this.formBuilder.group({
      userId :[''],
      password : ['',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*\\W).*$')]],
      confirmPassword : ['',[Validators.required]],
      oldPassword : ['',[Validators.required]]}
      ,
      { validators: [this.ConfirmedValidator('password', 'confirmPassword')] })
    this.editNameForm=this.formBuilder.group({
      userId :[''],
      name :['',[Validators.required,Validators.pattern('[a-zA-Z ]+')]],
      oldPassword : ['',[Validators.required]]
    })
    this.editPasswordForm.patchValue({
      userId: this.userId, 
    });
    this.editNameForm.patchValue({
      userId: this.userId, 
    });
    this.buyerProfileService.getUser(this.userId).subscribe(data=>{
      this.userDetail = data;
      this.editNameForm.patchValue({
        name: data.name, 
      });
      // console.log(this.userDetail);
    });

  }
  changePassword(){
    this.buyerProfileService.changeDetails(this.editPasswordForm.value,this.userId)
    .subscribe({
      next:(data)=>{
        this.editPasswordForm.reset();
        this.editName = false;
        this.editPassword = false;
      },
      error:(err)=>{
        if((JSON.parse(err.error).messages)[0]==="old password is not correct"){
          this.oldPassword = true
        }
        console.log(JSON.parse(err.error).messages)
      }
    })
  }
  changeName(){
    this.buyerProfileService.changeDetails(this.editNameForm.value,this.userId)
    .subscribe({
      next:(data)=>{
        this.userDetail.name = this.editNameForm.controls["name"].value;
        this.editName = false;
        this.editPassword = false;
        this.dataService.setUserName(this.userDetail.name);
      },
      error:(err)=>{
        if((JSON.parse(err.error).messages)[0]==="old password is not correct"){
          this.oldPassword = true
        }
        console.log(err.error)
      }
    })

  }
  editNameShow(){
    this.editName = true;
    this.editPassword = false;
  }
  editPasswordShow(){
    this.editName = false;
    this.editPassword = true;
  }
  clearOldPassword(){
   this.oldPassword = false;
  }
  cancel(){
    this.editName = false;
    this.editPassword = false;
    this.editNameForm.patchValue({
      name: this.userDetail.name, 
    });
    this.editPasswordForm.reset();
  }

  ConfirmedValidator(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];
      if (
        matchingControl.errors &&
        !matchingControl.errors.confirmedValidator
      ) {
        return;
      }
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ confirmedValidator: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
}
  }
