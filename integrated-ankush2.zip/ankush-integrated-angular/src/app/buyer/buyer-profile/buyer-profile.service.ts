import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BuyerProfileService {

  constructor(private http:HttpClient) { }

  getUser(id:any):Observable<any>{
    const requestOptions: Object = {
      headers: {
        'token': localStorage.getItem('token')
      }
    }
    return this.http.get<any>("http://localhost:9000/users/".concat(''+id),requestOptions);
  }
  changeDetails(data:any,id:any):Observable<any>{
    console.log(data)
    const requestOptions: Object = {
      responseType: 'text',
      headers: {
        'token': localStorage.getItem('token')
      }
    }
    return this.http.post<any>("http://localhost:9000/users/change-details/",data,requestOptions);
  }
}
