import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BuyerProfileComponent } from './buyer-profile/buyer-profile.component';
import { BuyerComponent } from './buyer.component';
import { BuyerOrderComponent } from '../buyer/buyer-order/buyer-order.component';
import { WishlistComponent } from '../buyer/wishlist/wishlist.component';

const routes: Routes = [
  { path: 'order', component: BuyerOrderComponent },
  { path: 'profile', component: BuyerProfileComponent },
  { path: 'wishlist', component: WishlistComponent },
  { path: '', component: BuyerComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BuyerRoutingModule { }
