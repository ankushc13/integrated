import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { DataService } from './data.service';
import { ProductsModule } from './products/products.module';
import { BuyerModule } from './buyer/buyer.module';
import { SharedModule } from './shared/shared.module';
import { DragScrollModule } from 'ngx-drag-scroll';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    ProductsModule,
    SharedModule,
    DragScrollModule,
    NgbModule,
    BuyerModule
  ],
  providers: [DataService,HomeComponent],  

  bootstrap: [AppComponent]
})
export class AppModule { }
