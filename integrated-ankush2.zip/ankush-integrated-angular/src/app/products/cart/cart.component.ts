import { Component, OnInit } from '@angular/core';
import { DataService } from '../../data.service';
import { Cart } from '../cart/Cart';
import { Order } from '../../buyer/buyer-order/Order';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  selectedProducts: any = [];
  subTotal = 0;
  userId:number = 0;
  totalDelivery = 0;
  bought = false;
  orders:any = [];

  constructor(private dataService: DataService) {
    this.subTotal = 0 ;
    this.bought = false;

    this.userId = parseInt(localStorage.getItem('userId')+'');
    if(this.userId===undefined ||  this.userId===null){
      this.userId = 0
    }
    this.selectedProducts = JSON.parse(
      localStorage.getItem('selectedProducts') + ''
    );
    this.orders = JSON.parse(
      localStorage.getItem('orders') + ''
    );
  }

  ngOnInit(): void {
    this.subTotal = 0 ;
    let cartValue = 0;
    this.selectedProducts.forEach((cart:Cart)=>{
      this.subTotal+=cart.totalPrice-cart.discount;
      cartValue+=cart.quantity;
    })
    this.dataService.setCart(cartValue);
  }

  increment(index: number, cart: Cart) {
    let cartTemp = this.selectedProducts[index];

    if (cartTemp.quantity < 4) {
      cart.quantity = cartTemp.quantity+1;
      cart.totalPrice = cartTemp.price*cart.quantity;
      cart.totalDeliveryCharge = cartTemp.totalDeliveryCharge+cartTemp.deliveryCharge
      this.selectedProducts[index] = cart;
      let cartValue = 0;
      this.dataService.getCart().forEach((data) => (cartValue = data));
      this.dataService.setCart(cartValue+1);
      localStorage.setItem('selectedProducts',JSON.stringify(this.selectedProducts));
      this.subTotal = 0;
      this.selectedProducts.forEach((cart:Cart)=>{
        this.subTotal+=cart.totalPrice-cart.discount;
      })
    
    }
  }
  decrement(index: number, cart: Cart) {
    let cartTemp = this.selectedProducts[index];
    if (cartTemp.quantity >= 1) {
      cart.quantity = cartTemp.quantity-1;
      cart.totalPrice = cartTemp.price*cart.quantity;
      if(cart.quantity==0){
        this.selectedProducts.splice(index, 1);
      }
      else{
        cart.totalDeliveryCharge = cartTemp.totalDeliveryCharge-cartTemp.deliveryCharge
        this.selectedProducts[index] = cart;
      }
      let cartValue = 0;
      this.dataService.getCart().forEach((data) => (cartValue = data));
      this.dataService.setCart(cartValue-1);
      localStorage.setItem('selectedProducts',JSON.stringify(this.selectedProducts));
      this.subTotal = 0;
      this.selectedProducts.forEach((cart:Cart)=>{
        this.subTotal+=cart.totalPrice-cart.discount;
      })
      if(this.subTotal<0){
        this.subTotal = 0;
      }
    
    }
    console.log("qauntity",cart.quantity , cart.cartId)
      if(cart.quantity===0 && cart.cartId!==undefined && cart.cartId!==null){
        console.log("remove")
        this.dataService.removeCart(cart.cartId).subscribe(()=> console.log("amk"));
      }
  }
  tDelivery():number{
    var temp = 0;
    this.selectedProducts.forEach((cart:Cart)=>{
      temp+=cart.totalDeliveryCharge;
    })
    return temp
  }
  checkout(){
    this.orders = []
    this.selectedProducts.forEach((cart:Cart)=>{
      let order:Order;
      order = cart
      order.orderType = 'open'
      this.orders.push(order);
    })
    this.bought = true;
    this.orders.forEach((order:Order)=>{
      this.dataService.addOrder(order).subscribe(data=>console.log(data));
    })
    this.selectedProducts = []
    localStorage.removeItem('selectedProducts')
    this.dataService.setCart(0);

  }
  subtotalAmount():number{
    var temp = 0;
    if(this.subTotal<1000){
      this.selectedProducts.forEach((cart:Cart)=>{
        temp+=cart.totalDeliveryCharge;
      })
    }
      return temp+this.subTotal;
  }
  discard():boolean{
      return this.subTotal>=1000;
  }
}
