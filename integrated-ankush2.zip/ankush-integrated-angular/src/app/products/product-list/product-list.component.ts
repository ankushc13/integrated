import { ProductService } from '../product.service';
import { Component, OnInit, Input } from '@angular/core';
import { DataService } from '../../data.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import constant from '../../../assets/constant'

@Component({
    templateUrl: 'product-list.component.html',
    styleUrls: ['product-list.component.css']
})
export class ProductListComponent implements OnInit {
  readonly CONSTANT = constant;
    products!:any[]
  carts!:any[]
  filterText = '';
  selectedItems: any = 0;
  selectedProduct: any = 0;
  noItem!:boolean;
   userId = 0;
  constructor(private router: Router,private productService:ProductService,private dataService:DataService) {
    this.userId = parseInt(localStorage.getItem('userId')+'');
    if(this.userId===undefined ||  this.userId===null){
      this.userId = 0
    }
    this.dataService.getValue().subscribe(data=>{
      this.filterText = data;
    })
   }
  ngOnInit(){
    this.noItem = true;
    this.getProducts();
  }
  addCart(item:any){
      this.selectedItems+=1

  }
  getProducts(){
    this.products=[];
    this.productService.getProducts().subscribe(res=>{
      this.products=res;
      localStorage.setItem('totalProducts', JSON.stringify(this.products));
    })
  }
  addWish(id:number){
    let wish =  {
      productId: id,
      userId:this.userId
    }
    this.dataService.addWishList(wish).subscribe(res=>console.log(res))
  }
  getProductDetails(id:number){
    this.router.navigate(['/products/'+id]);
  }
}


