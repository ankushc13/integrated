import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from './product.service';

@Component({
    selector: 'app-products',
    templateUrl: 'products.component.html'
})
export class ProductComponent {
    pageTitle = 'Product Detail';
    

    constructor(private route: ActivatedRoute,
        private router: Router, public productService: ProductService) {
    }
    onBack(): void {
        this.router.navigate(['/home']);
    }

}
