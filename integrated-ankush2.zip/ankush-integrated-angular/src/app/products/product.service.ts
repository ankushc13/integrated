import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators'


@Injectable()
export class ProductService {

    selectedProducts: any = [];
    products: any = [];
    username: string = '';


    constructor(private http: HttpClient) {
        if (sessionStorage.getItem('selectedProducts')) {
            this.selectedProducts = JSON.parse(sessionStorage.getItem('selectedProducts') + '');
        }
    }

    getProducts():Observable<any[]>{
        return this.http.get<any[]>("http://localhost:9000/products");
      }
}
