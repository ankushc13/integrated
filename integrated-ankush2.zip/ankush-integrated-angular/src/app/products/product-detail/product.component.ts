import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';
import { Component, OnInit, Input } from '@angular/core';
import { MinPipe } from '../../shared/pipe/min.pipe'
import { Cart } from '../cart/Cart'
import { ViewportScroller } from '@angular/common';
import { DataService } from '../../data.service';

@Component({
    templateUrl: 'product.component.html',
    styleUrls: ['product.component.css'],
    providers: [
        MinPipe
    ],
})
export class ProductComponent implements OnInit{
    pageTitle = 'Product Detail';
    product: any;
    products: any[];
    id = 0;
    cart = 0;
    currentSeller:any;
    currentOffer:any;
    selectedValue = null;
    math = Math;
    stars: number[] = [1, 2, 3, 4, 5];
    cartPredefine: number[] = [1, 2, 3, 4];
    selectedProducts: any = [];
    carts!:Cart;
    limit!:boolean;

    constructor(private route: ActivatedRoute,
        private router: Router, public productService: ProductService
        ,private minPipe: MinPipe,private scroll: ViewportScroller,private dataService: DataService) {
        this.id = +this.route.snapshot.paramMap.get('id')!;
        this.products = JSON.parse(localStorage.getItem('totalProducts')+'');
        this.product = this.products.filter((product: any) => product.productId === this.id)[0];
        
    }
    ngOnInit(): void {
        this.getCurrentSeller();
        this.limit = false;
        // localStorage.removeItem('selectedProducts');
    }
    onSelect(value:any){

    }
    limitFalse(){
        this.limit = false;
    }
    pipeMinFilter(){
        let m = 0
        if(this.currentSeller!=null){
            m = this.currentSeller.discount
        }
        return this.currentSeller.price-m;
    }
    getCurrentSeller(){
        var array = this.product.sellerList;
        let min = Number.POSITIVE_INFINITY;
        let temp;
        var current = Object.keys(array).map(function(key){
            let seller = array[key];
            return seller;
        });
        current.forEach(function (v) 
        {
             if(v.price<min){
                temp = v
                min = v.price;
            }
        }); 
        this.currentSeller = temp;
    }
    
    onBack(): void {
        this.router.navigate(['/home']);
    }
    
    addProduct() {
        this.selectedProducts = JSON.parse(localStorage.getItem('selectedProducts')+'');
        if(this.selectedProducts!=null){
            var index = this.selectedProducts.findIndex( (cart: Cart) => {
                return this.product.productId === cart.productId && this.currentSeller.sellerId === cart.sellerId});
            this.carts = this.selectedProducts[index]
            if(index!=-1){
                this.carts.quantity+=this.cart
            }
        }
        else if(this.selectedProducts==null){
            this.selectedProducts = [];
            index = -1
        }
        console.log(index,"index");
        if(index==-1){
            this.carts = new Cart();
            this.carts.productId = this.product.productId;
            this.carts.productName = this.product.productName;
            this.carts.quantity+=this.cart
            this.carts.sellerId = this.currentSeller.sellerId;
            let userId = parseInt(localStorage.getItem('userId')+'');
            this.carts.userId = userId===0?null:userId;
            this.carts.discount = this.currentSeller.discount;
            this.carts.sellerName = this.currentSeller.sellerName;
            this.carts.discount = this.currentSeller.discount;
            this.carts.imageUrl = this.product.imageUrl;
            this.carts.price = this.currentSeller.price;
            this.carts.deliveryCharge = this.currentSeller.deliveryPrice
        }
        let cartValue =  0;
        this.dataService.getCart().forEach(data=>cartValue=data);
        if(this.carts.quantity<=4){
            this.carts.dateOfPurchase = new Date().toString();
            this.carts.totalPrice = this.currentSeller.price*this.carts.quantity;
            this.carts.totalDeliveryCharge = this.currentSeller.deliveryPrice*this.carts.quantity;
            if(index==-1){
                this.selectedProducts.push(this.carts);
            }
            else{
                this.selectedProducts[index] = this.carts;
            }
            cartValue+=this.cart;
            console.log(this.selectedProducts,cartValue)
            localStorage.setItem('selectedProducts',JSON.stringify(this.selectedProducts));
        }
        else{
            this.limit = true
        }
        this.dataService.setCart(cartValue)
        this.cart = 0;
    }
}